// eslint-disable-next-line linebreak-style
/* eslint-disable no-use-before-define */
import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.scss';
import './components/AppBar/appbar';
import './components/Hero';
import './components/List';
import './components/Banner';
import App from './views/app';
import swRegister from './utils/sw-register';

// const menu = document.querySelector('#menu');
// const ListElement = document.querySelector('data-list');

// const getData = () => {
//   renderResult(data.restaurants);
// };
// menu.addEventListener('click', (event) => {
//   // eslint-disable-next-line no-undef
//   drawer.classList.toggle('open');
//   event.stopPropagation();
// });

// menu.addEventListener('keypress', (event) => {
//   if (event.key === 'Enter') {
//     // eslint-disable-next-line no-undef
//     drawer.classList.toggle('open');
//     event.stopPropagation();
//   }
// });

// const renderResult = (results) => {
//   ListElement.data = results;
// };

// document.addEventListener('DOMContentLoaded', () => {
//   getData();
// });

const app = new App({
  button: document.querySelector('#menu'),
  drawer: document.querySelector('#drawer'),
  content: document.querySelector('#maincontent'),
});

window.addEventListener('hashchange', () => {
  app.renderPage();
});

window.addEventListener('load', () => {
  app.renderPage();
  swRegister();
});
